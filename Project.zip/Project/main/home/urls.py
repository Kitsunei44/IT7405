from django.urls import path
from . import views
from django.views.i18n import JavaScriptCatalog

urlpatterns = [
    path('',views.index,name="home" ),
    path('search_result',views.SearchResult,name="search_result"),
    path('process/',views.process,name="process"),
    path('jsi18n', JavaScriptCatalog.as_view(), name='js-catlog'),
    #Gear Urls
    path('gear/',views.GearView.as_view(),name="gear"),
    path('add_gear/',views.AddGearView.as_view(),name="add_gear"),
    path('gear_detail/<int:pk>',views.GearDetailView.as_view(),name="gear_detail"),
    path('update_gear/<int:pk>',views.UpdateGearView.as_view(),name="update_gear"),
    path('delete_gear/<int:pk>',views.DeleteGearView.as_view(),name="delete_gear"),
    #Vehicle Urls
    path('vehicle/',views.VehicleView.as_view(),name="vehicle"),
    path('add_vehicle/',views.AddVehicleView.as_view(),name="add_vehicle"),
    path('vehicle_detail/<int:pk>',views.VehicleDetailView.as_view(),name="vehicle_detail"),
    path('update_vehicle/<int:pk>',views.UpdateVehicleView.as_view(),name="update_vehicle"),
    path('delete_vehicle/<int:pk>',views.DeleteVehicleView.as_view(),name="delete_vehicle"),
    #Appointment Urls
    path('add_appointment/',views.AddAppointmentView.as_view(),name="add_appointment"),
    path('appointment/',views.AppointmentView.as_view(),name="appointment"),
    path('appointment_admin/',views.AppointmentAdminView.as_view(),name="appointment_admin"),
    path('delete_appointment/<int:pk>',views.DeleteAppointmentView.as_view(),name="delete_appointment"),
    path('delete_appointment_admin/<int:pk>',views.DeleteAppointmentViewAdmin.as_view(),name="delete_appointment_admin"),
]
