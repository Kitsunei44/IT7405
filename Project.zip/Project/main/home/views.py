from django.shortcuts import render
from django.views.generic import ListView,DetailView,CreateView,UpdateView,DeleteView
from django.db.models import Q
from .models import Gear , Vehicle , Appointment
from .forms import GearForm , VehicleForm , AppointmentForm
from django.contrib.auth.mixins import LoginRequiredMixin




# Create your views here.
def index(request):
    return render(request, 'index.html',{})

def process(request):
    return render(request, 'process.html',{})

def SearchResult(request):
    if request.method == "POST":
        searched = request.POST.get('searched')
        results = Gear.objects.filter(Q(body__icontains=searched) | Q(title__icontains=searched))
        results1 = Vehicle.objects.filter(Q(body__icontains=searched) | Q(title__icontains=searched))
        return render(request, 'search_result.html',{'searched':searched,'results':results,'results1':results1},)
    else:
        return render(request, 'search_result.html',{})
#Gear Views
class AddGearView(CreateView):
    model = Gear
    form_class =GearForm
    success_url = '/gear/'
    template_name = 'gear/add_gear.html'

class GearView(ListView):
    model = Gear
    template_name = 'gear/gears.html'

class GearDetailView(DetailView):
    model = Gear
    template_name = 'gear/gear_detail.html'

class UpdateGearView(UpdateView):
    model = Gear
    form_class =GearForm
    success_url = '/gear/'
    template_name = 'gear/update_gear.html'

class DeleteGearView(DeleteView):
    model = Gear
    form_class =GearForm
    success_url = '/gear/'
    template_name = 'gear/delete_gear.html'
#Vehicle Views
class AddVehicleView(CreateView):
    model = Vehicle
    form_class =VehicleForm
    success_url = '/vehicle/'
    template_name = 'vehicle/add_vehicle.html'

class VehicleView(ListView):
    model = Vehicle
    template_name = 'vehicle/vehicle.html'

class VehicleDetailView(DetailView):
    model = Vehicle
    template_name = 'vehicle/vehicle_detail.html'

class UpdateVehicleView(UpdateView):
    model = Vehicle
    form_class =VehicleForm
    success_url = '/vehicle/'
    template_name = 'vehicle/update_vehicle.html'

class DeleteVehicleView(DeleteView):
    model = Vehicle
    form_class =VehicleForm
    success_url = '/vehicle/'
    template_name = 'vehicle/delete_vehicle.html'

#Appointment Views
class AddAppointmentView(LoginRequiredMixin, CreateView):
    model = Appointment
    form_class = AppointmentForm
    success_url = ''
    template_name = 'appointment/add_appointment.html'

    def form_valid(self, form):
        form.instance.user = self.request.user
        return super().form_valid(form)

    def get_initial(self):
        initial = super().get_initial()
        initial['user'] = self.request.user
        return initial

    def get_form(self, form_class=None):
        form = super().get_form(form_class)
        form.fields['user'].widget.attrs['disabled'] = False
        return form
    
    


class AppointmentView(ListView):
    model = Appointment
    template_name = 'appointment/appointment.html'
    def get_queryset(self):
        return Appointment.objects.filter(user=self.request.user)

class AppointmentAdminView(ListView):
    model = Appointment
    template_name = 'appointment/appointment_admin.html'


class DeleteAppointmentView(DeleteView):
    model = Appointment
    form_class =AppointmentForm
    success_url = '/appointment/'
    template_name = 'appointment/delete_appointment.html'

class DeleteAppointmentViewAdmin(DeleteView):
    model = Appointment
    form_class =AppointmentForm
    success_url = '/appointment_admin/'
    template_name = 'appointment/delete_appointment_admin.html'
