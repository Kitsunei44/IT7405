from django.contrib import admin
from .models import Gear, Vehicle

# Register your models here.
admin.site.register(Gear)
admin.site.register(Vehicle)