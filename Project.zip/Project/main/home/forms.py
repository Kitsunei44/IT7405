from django import forms
from .models import Gear, Vehicle, Appointment
from django.contrib.admin.widgets import AdminDateWidget, AdminTimeWidget


class GearForm(forms.ModelForm):
    class Meta:
        model = Gear
        fields = ('title','title_tag','body','header_image','price')

#A MODELFORM helps to create fields for the model

        widgets = {
            'title' : forms.TextInput(attrs={'class': 'form-control'}),
            'title_tag' : forms.TextInput(attrs={'class': 'form-control','placeholder':'This is a Title Placeholder'}),
            'body' : forms.Textarea(attrs={'class': 'form-control'}),
            'header_image' : forms.FileInput(attrs={ 'class': 'form-control'}),
            'price' : forms.NumberInput(attrs={ 'class': 'form-control'}),
        }


class VehicleForm(forms.ModelForm):
    class Meta:
        model = Vehicle
        fields = ('title','title_tag','body','header_image','make','engineSize','persons','weight','price')

#A MODELFORM helps to create fields for the model

        widgets = {
            'title' : forms.TextInput(attrs={'class': 'form-control'}),
            'title_tag' : forms.TextInput(attrs={'class': 'form-control','placeholder':'This is a Title Placeholder'}),
            'body' : forms.Textarea(attrs={'class': 'form-control'}),
            'header_image' : forms.FileInput(attrs={ 'class': 'form-control'}),
            'make' : forms.TextInput(attrs={'class': 'form-control'}),
            'engineSize' : forms.TextInput(attrs={'class': 'form-control'}),
            'persons' : forms.NumberInput(attrs={'class': 'form-control'}),
            'weight' : forms.TextInput(attrs={'class': 'form-control'}),
            'price' : forms.NumberInput(attrs={ 'class': 'form-control'}),
        }

class AppointmentForm(forms.ModelForm):
    class Meta:
        model = Appointment
        fields = ('fname','lname','cpr','branch','contact_num','user','appointment_date','appointment_time')

#A MODELFORM helps to create fields for the model

        widgets = {
            'fname' : forms.TextInput(attrs={'class': 'form-control'}),
            'lname' : forms.TextInput(attrs={'class': 'form-control'}),
            'cpr' : forms.NumberInput(attrs={'class': 'form-control'}),
            'branch' : forms.Select(attrs={'class': 'form-control'}),
            'contact_num' : forms.NumberInput(attrs={'class': 'form-control'}),
            'user' : forms.HiddenInput(attrs={'class': 'form-control','readonly': True}),
            'appointment_date' : AdminDateWidget(),
            'appointment_time' : AdminTimeWidget(),
        }

        labels = {
            'fname': 'First Name',
            'lname' : 'Last Name',
            'cpr' : 'CPR',
            'contact_num' : 'Contact Number'
        }

