from django.db import models
from django.contrib.auth.models import User
from django.urls import reverse


# Create your models here.
class Gear(models.Model):
    title=models.CharField(max_length=255)
    header_image= models.ImageField(null=False,blank=False, upload_to ="images/",default="images/default.png")
    title_tag=models.CharField(max_length=255)
    body=models.TextField()
    price=models.FloatField()

class Vehicle(models.Model):
    title=models.CharField(max_length=255)
    header_image=models.ImageField(null=False,blank=False,upload_to="images/",default="images/default.png")
    title_tag=models.CharField(max_length=255)
    body=models.TextField(null=True,blank=True)
    make=models.CharField(max_length=255,null=True,blank=True)
    engineSize=models.CharField(max_length=255,null=True,blank=True)
    persons=models.IntegerField(null=True,blank=True)
    weight=models.CharField(max_length=255,null=True,blank=True)
    price=models.FloatField()

branches = (
    ('sitra','Sitra'),
    ('manama', 'Manama'),
    ('salman_city','Salman City'),
)

class Appointment(models.Model):
    fname = models.CharField(max_length=25)
    lname = models.CharField(max_length=25)
    cpr = models.IntegerField()
    branch = models.CharField(max_length=25,choices=branches, default='sitra')
    contact_num = models.IntegerField()
    user = models.ForeignKey(User,on_delete =models.CASCADE)
    appointment_date = models.DateField()
    appointment_time = models.TimeField()


    
    def get_absolute_url(self):
        #return reverse('article-detail', args = [str(self.id)]) 
        return reverse('home')
# Please note, article-detail passed as argument in reverse is the name value given in urls.py
#This is where the page need to redirect after clicking the post button,
#self .id is the kind of the primary key created for each field.