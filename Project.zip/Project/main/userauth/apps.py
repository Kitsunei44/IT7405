from django.apps import AppConfig


class UserauthConfig(AppConfig):
    name = 'userauth'
